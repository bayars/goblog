package pkg

import "testing"

func TestFoo(t *testing.T) {
	if fn1() == true {
	}
}
