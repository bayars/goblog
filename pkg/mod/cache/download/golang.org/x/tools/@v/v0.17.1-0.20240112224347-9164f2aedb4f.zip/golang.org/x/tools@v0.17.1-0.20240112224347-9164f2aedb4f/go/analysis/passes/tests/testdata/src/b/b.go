package b

type Foo struct {
}

func (f *Foo) F() {

}
