// should pass if  skipPackageNameChecks = true

package pkg_with_underscores
