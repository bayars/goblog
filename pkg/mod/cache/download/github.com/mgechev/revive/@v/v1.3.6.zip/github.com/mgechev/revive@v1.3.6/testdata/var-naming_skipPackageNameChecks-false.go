// should fail if skipPackageNameChecks = false (by default)

package pkg_with_underscores // MATCH /don't use an underscore in package name/
