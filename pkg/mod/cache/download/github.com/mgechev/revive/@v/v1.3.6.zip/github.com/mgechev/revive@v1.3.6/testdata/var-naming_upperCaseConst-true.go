// should pass if upperCaseConst = true

package fixtures

const SOME_CONST_2 = 2
const _SOME_PRIVATE_CONST_2 = 2

const (
	SOME_CONST_3          = 3
	_SOME_PRIVATE_CONST_3 = 3
	VER                   = 0
)
